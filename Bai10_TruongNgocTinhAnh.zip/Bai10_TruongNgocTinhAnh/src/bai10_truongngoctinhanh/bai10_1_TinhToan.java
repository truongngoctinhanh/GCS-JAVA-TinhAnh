/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai10_1_TinhToan {

    /**
     * @param args the command line arguments
     */
    
    
    enum toanTu{
            CONG, TRU, NHAN, CHIA;
        double tinhToan(double x, double y){  
            switch (this){
                case CONG:
                    return x + y;
                case TRU:
                    return x - y;
                case NHAN:
                    return x * y;
                case CHIA:
                    if(y == 0) throw new ArithmeticException("Không thể thực hiện phép chia vì y = 0");
                    return x / y;
                default:
                    throw new AssertionError("Bạn nhập sai toán tử" + this);
                    
                   
            }
        }
    }
    
    public static void main(String[] args){
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập a: ");
        try{
        int a = Integer.parseInt(input.readLine());
        System.out.println("Nhập b: ");
        int b = Integer.parseInt(input.readLine());
        double result1 = toanTu.CONG.tinhToan(a, b);
        System.out.println(a + " + " + b + " = " + result1);
        double result2 = toanTu.TRU.tinhToan(a, b);
        System.out.println(a + " - " + b + " = " + result2);
        double result3 = toanTu.NHAN.tinhToan(a, b);
        System.out.println(a + " * " + b + " = " + result3);
        double result4 = toanTu.CHIA.tinhToan(a, b);
        System.out.println(a + " / " + b + " = " + result4);
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
