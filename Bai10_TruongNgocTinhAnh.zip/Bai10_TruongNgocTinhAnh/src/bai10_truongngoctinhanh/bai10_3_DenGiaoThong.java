/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_truongngoctinhanh;

/**
 *
 * @author hocvien
 */
public class bai10_3_DenGiaoThong {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        for(DenGiaoThong den : DenGiaoThong.values()){
            System.out.printf("%s: %d giây, tiếp theo là đèn %s\n", den, den.getSoGiay(), den.chuyenDen());
        }
        
        System.out.println(Den.XANH.chuyenDen(30));
        System.out.println(Den.DO.chuyenDen(30));
        System.out.println(Den.VANG.chuyenDen(10));
        
    }
}
    enum DenGiaoThong{
        DO(30){
                @Override
                public DenGiaoThong chuyenDen(){
                return XANH;
                }
            },
        VANG(10){
                @Override
                public DenGiaoThong chuyenDen(){
                return DO;
                }
            },
        XANH(30){
                @Override
                public DenGiaoThong chuyenDen(){
                return VANG;
                }
            };
        
        private DenGiaoThong (int soGiay){
            this.soGiay = soGiay;
        }
        public abstract DenGiaoThong chuyenDen();
        private final int soGiay;
        public int getSoGiay(){
            return soGiay;
        }
        
    }        
        enum Den{
        DO, VANG, XANH;
        String chuyenDen(int soGiay){
            switch(this){
                case XANH:
                    return " Xanh chuyển sang vàng sau " + soGiay + " giây";
                case DO:
                    return " Đỏ chuyển sang xanh sau " + soGiay + " giây";
                case VANG:
                    return " Vàng chuyển sang đỏ sau " + soGiay + " giây"; 
                default:
                    throw new AssertionError("Không tìm được đèn phù hợp");
            }
        }
    }