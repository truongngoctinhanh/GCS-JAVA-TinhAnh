/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai10_2_TroChoi {

    /**
     * @param args the command line arguments
     */
    
    enum chonLua{
        KEO(0),
        BUA(1),
        BAO(2);
        private int ketQua;

        private chonLua(int ketQua) {
            this.ketQua = ketQua;
        }

        public int getKetQua() {
            return ketQua;
        }
        
    }

    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        try{
        System.out.println("Cùng chơi kéo, búa, bao nhé !!!!");
        System.out.println("Bạn có muốn chơi không ????(y/n)");
        String choi = input.readLine();
        if(choi.equalsIgnoreCase("y")){
            boolean tiepTuc = true;
            int soLanChoi = 0;
            int diemNguoiChoi = 0;
            int diemMay = 0;
            int mayChon = 0;
            int nguoiChon = 0;
            
            while(tiepTuc){
                System.out.println("Hãy chọn s nếu bạn muốn ra kéo \n "
                        + "Chọn p nếu bạn muốn ra bao \n Chọn t nếu bạn muốn ra búa: ");
                String chon = input.readLine();
                switch(chon){
                    case "p":
                        System.out.println("Bạn ra bao");
                        nguoiChon = chonLua.BAO.getKetQua();
                        break;
                    case "t":
                        System.out.println("Bạn ra búa");
                        nguoiChon = chonLua.BUA.getKetQua();
                        break;
                    case "s":
                        System.out.println("Bạn ra kéo");
                        nguoiChon = chonLua.KEO.getKetQua();
                }
                mayChon = new Random().nextInt(2);
                switch(mayChon){
                    case 0:
                        System.out.println("Máy ra kéo");break;
                    case 1:
                        System.out.println("Máy ra búa");break;
                    case 2:
                        System.out.println("Máy ra bao");break;
                }
                if(mayChon == nguoiChon)
                    System.out.println("Ngang tài ngang sức");
                else{
                        if(nguoiChon == 1){
                            if(mayChon == 0){
                                System.out.println("Chúc mừng bạn đã chiến thắng!");
                                diemNguoiChoi++;
                            }
                            else if(mayChon == 2){
                                System.out.println("Oh no, bạn đã thua rồi!");
                                diemMay++;
                            }
                        }
                        else if(nguoiChon == 0){
                            if(mayChon == 2){
                                System.out.println("Chúc mừng bạn đã chiến thắng!");
                                diemNguoiChoi++;
                            }
                            else if(mayChon == 1){
                                System.out.println("Oh no, bạn đã thua rồi!");
                                diemMay++;
                            }
                        }
                        else{
                            if(mayChon == 1){
                                System.out.println("Chúc mừng bạn đã chiến thắng!");
                                diemNguoiChoi++;
                            }
                            else if(mayChon == 0){
                                System.out.println("Oh no, bạn đã thua rồi!");
                                diemMay++;
                            }
                        }
                }
                System.out.println("Số lần chơi: " + soLanChoi);
                System.out.println("Điểm của bạn: " + diemNguoiChoi);
                System.out.println("Điểm của máy: " + diemMay);
                soLanChoi++;
                if(diemNguoiChoi == 5 || diemMay == 5){
                    tiepTuc = false;
                }
                
            }
            System.out.println("Tống số lần chơi: "+soLanChoi);
            if(diemNguoiChoi > diemMay)
                System.out.println("Bạn đã chiến thắng");
            else
                System.out.println("Bạn đã thua rồi");
        }
        else
            System.out.println("Dừng trò chơi");
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());    
        }
        
    }

}