/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BaiTap_String_BoSung;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class bai1_6_PhanTachChuoi {

    /**
     * @param args the command line arguments
     */
    
     public static void tachChuoi(String t, String kt){
        StringTokenizer st = new StringTokenizer(t, kt);
        System.out.println("Các toKen: ");
        while(st.hasMoreTokens()){
            System.out.println(st.nextToken());
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào chuỗi cần phân tách: ");
        try{
        String t = input.readLine();
        System.out.println("Nhập vào ký tự phân tách: ");
        String kt = input.readLine();
        
        tachChuoi(t, kt);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
