/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part2_truongngoctinhanh;

import static bai11_part2_truongngoctinhanh.bai11_5_TimeFormat.kiemTraGio;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai11_6_UsernameFormat {

    /**
     * @param args the command line arguments
     */
    
    public static void kiemTraUsername(String u){
        String regexp = ("[a-z0-9_-]{6,20}");
        Pattern pattern = Pattern.compile(regexp);
        Matcher m = pattern.matcher(u);
        boolean b = m.matches();
        if(b == true){
            System.out.println("Bạn đã nhập Username hợp lệ");
        }else
            System.out.println("Bạn đã nhập Username không hợp lệ");
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào Username: ");
        try{
        String u = input.readLine();
        
        kiemTraUsername(u);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
