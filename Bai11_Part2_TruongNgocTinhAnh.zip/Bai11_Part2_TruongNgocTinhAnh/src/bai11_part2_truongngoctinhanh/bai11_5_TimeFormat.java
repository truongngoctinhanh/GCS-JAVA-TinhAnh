/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part2_truongngoctinhanh;

import static bai11_part2_truongngoctinhanh.bai11_4_PhanTachHoTen.tachHoTen;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai11_5_TimeFormat {

    /**
     * @param args the command line arguments
     */
    
    public static void kiemTraGio(String t){
        String regexp = ("([0]?[0-9]|[1][0-9]|[2][0-3])[:]([0][0-9]|[1-5][0-9])");
        Pattern pattern = Pattern.compile(regexp);
        Matcher m = pattern.matcher(t);
        boolean b = m.matches();
        if(b == true){
            System.out.println("Bạn đã nhập giờ hợp lệ");
        }else
            System.out.println("Bạn đã nhập giờ không hợp lệ");
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào giờ: ");
        try{
        String t = input.readLine();
        
        kiemTraGio(t);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
