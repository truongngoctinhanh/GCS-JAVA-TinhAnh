/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part2_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class bai11_3_PhanTachNgayThangNam {

    /**
     * @param args the command line arguments
     */
    
    public static void tachNgayThangNam(String t){
        StringTokenizer st = new StringTokenizer(t, "-");
            System.out.println("Ngày: " + st.nextToken());
            System.out.println("Tháng: " + st.nextToken());
            System.out.println("Năm: " + st.nextToken());
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào ngày tháng năm (ví dụ: 10-12-1993): ");
        try{
        String t = input.readLine();
        
        tachNgayThangNam(t);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
