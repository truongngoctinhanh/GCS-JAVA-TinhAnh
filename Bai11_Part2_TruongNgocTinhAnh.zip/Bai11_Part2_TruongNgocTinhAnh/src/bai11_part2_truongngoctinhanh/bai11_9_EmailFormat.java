/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part2_truongngoctinhanh;

import static bai11_part2_truongngoctinhanh.bai11_8_DateFormat.kiemTraNgay;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai11_9_EmailFormat {

    /**
     * @param args the command line arguments
     */
    
    public static void kiemTraEmail(String ngay){
        String regexp = ("([_\\w-\\+])+(\\.[_\\-+]+)*[@]([\\w-])+(\\.[\\w])+\\.([\\w]{2,}+)*");
        Pattern pattern = Pattern.compile(regexp);
        Matcher m = pattern.matcher(ngay);
        boolean b = m.matches();
        if(b == true){
            System.out.println("Bạn đã nhập Email hợp lệ");
        }else
            System.out.println("Bạn đã nhập Email không hợp lệ");
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào Email: ");
        try{
        String ngay = input.readLine();
        
        kiemTraEmail(ngay);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
