/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.kiemTraChuoi;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.nhapMang;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.sapXepMang;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.timPhanTuDaiNhat;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.xuatMang;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai5_MangNgauNhien {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    
        Random random = new Random();
        for(int i = 0; i < n; i++){
            mang[i] = random.nextInt(n - 1);            
        }
    }
    
    public static void xuatMang(int[] mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
        
    public static String[][] taoMang1(String[][] mang, int[] viTri) {

        int i, j;
        for (i = 0; i < mang.length; i++) {
            for (j = 0; j <mang[i].length; j++ ) {
                if(j == viTri[i])
                    mang[i][j] = "Q";
                else
                    mang[i][j] = "*";
            }
        }
        return mang;
    }

    public static void taoMang2(String[][] mang) {

        if (mang == null) {
            System.out.println("Mảng đang có giá trị null");
        }
        String chuoi = "";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                chuoi += mang[i][j] + " ";
            }
            System.out.println(chuoi);
            chuoi = "";
        }

    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập n : ");
        try{
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];
        nhapMang(a, n);
        xuatMang(a);
        
        String[][] b = new String[n][n];
        
        String[][] mangMoi = new String[n][n];
        mangMoi = taoMang1(mangMoi, a);
        taoMang2(mangMoi);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
