/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai7DoiChuoi {

    /**
     * @param args the command line arguments
     */
    
    public static String doiThapPhanSangThapLucPhan (int n){
        
        String s = "";
        String tam = "";
        while(n > 0){
            tam = s.valueOf(n % 16);
            switch(tam){
            case "0": case "1": case "2": case "3": case "4": case "5": 
            case "6": case "7": case "8": case "9":
                s = s + tam; break; 
            case "10":
                s = s + "A"; break;
            case "11":
                s = s + "B"; break;
            case "12":
                s = s + "C"; break;
            case "13":
                s = s + "D"; break;
            case "14":
                s = s +"E"; break;
            case "15":
                s = s + "F"; break;
            }
            n = n / 16;
        } 
        
        return s;
        
    }
    
    public static String daoChuoi(String s) {
		StringBuilder sb = new StringBuilder();
		for (int i = s.length() - 1; i >= 0; i--) {
			sb.append(s.charAt(i));
		}
		return sb.toString();
    }
    
    public static int doiThapLucPhanSangThapPhan (String n){
        int re = 0;
        int tmp = n.length() - 1;
        for (int i = 0; i < n.length(); i++){
            int num;
            switch(n.charAt(i)+""){
                case "A":
                    num = 10; break;
                case "B":
                    num = 11; break;
                case "C":
                    num = 12; break;
                case "D":
                    num = 13; break;
                case "E":
                    num = 14; break;
                case "F":
                    num = 15; break;
                default:
                    num = Integer.parseInt(n.charAt(i) + "");
                    break;
            }
            re += num * Math.pow(16, tmp);
            tmp--;
        }
        return re;
    }
    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập số thập phân: ");
        try{
        int n1 = Integer.parseInt(input.readLine());
        System.out.println("Nhập số thập thập phân: ");
        String n2 = input.readLine();
        System.out.print("Số thập phân " + n1 + " chuyển sang thập lục phân = ");
        String b = doiThapPhanSangThapLucPhan(n1);
        System.out.println(daoChuoi(b));
        System.out.println("\nSố thập lục phân " + n2 + " chuyển sang thập phân = " +doiThapLucPhanSangThapPhan(n2));
            
        } catch(InputMismatchException | NumberFormatException | ArithmeticException e){
            System.out.println("Lỗi: " + e.getMessage());
        }
    }
    
}
