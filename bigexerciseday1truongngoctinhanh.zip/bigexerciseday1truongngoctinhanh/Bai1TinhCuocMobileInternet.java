/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

/**
 *
 * @author hocvien
 */
public class Bai1TinhCuocMobileInternet{

    /**
     * @param args the command line arguments
     */
    enum mucCuoc{
        M0(0, 0, 1.5),
        M10(10000, 51200, 0.5),
        M25(25000, 153600, 0.5),
        M50(50000, 512000, 0.5),
        M120(120000, 1572864, 0.5),
        MAX(70000, 614400, 0.5),
        MAX100(100000, 1258291.2, 0.5),
        MAX200(200000, 3145728, 0.5),
        MAXS(50000, 2097152, 0.5);

        private double cuocPhi;
        private double dungLuongMienPhi;
        private double cuocPhiThem;

        private mucCuoc(double cuocPhi, double dungLuongMienPhi, double cuocPhiThem) {
            this.cuocPhi = cuocPhi;
            this.dungLuongMienPhi = dungLuongMienPhi;
            this.cuocPhiThem = cuocPhiThem;
        }
        public static mucCuoc getM0(){
            return M0;
        }
        public static mucCuoc getM10(){
            return M10;
        }
        public static mucCuoc getM25(){
            return M25;
        }
        public static mucCuoc getM50(){
            return M50;
        }
        public static mucCuoc getM120(){
            return M120;
        }
        public static mucCuoc getMAX(){
            return MAX;
        }
        public static mucCuoc getMAX100(){
            return MAX100;
        }
        public static mucCuoc getMAX200(){
            return MAX200;
        }
        public static mucCuoc getMAXS(){
            return MAXS;
        }
        public double getTienCuoc(){
            return cuocPhi;
        }
        public double getDungLuongMienPhi(){
            return dungLuongMienPhi;
        }
        public double getTienCuocThem(){
            return cuocPhiThem;
        }

        public double tinhTien(double dungLuong){

            double tien = 0;

            if (dungLuong > this.getDungLuongMienPhi()){
                dungLuong = dungLuong - this.getDungLuongMienPhi();
                tien = this.getTienCuoc() + dungLuong * this.getTienCuocThem();
            } else {
                tien = this.getTienCuoc();
            }
            return tien;
        }

    }
    
    public static double tinhTienCuoc(String tenCuoc, double dungLuong) {

        double tien = 0;
        switch (tenCuoc) {
            case "M0":
                tien = mucCuoc.M0.tinhTien(dungLuong);
                break;
            case "M10":
                tien = mucCuoc.M10.tinhTien(dungLuong);
                break;
            case "M25":
                tien = mucCuoc.M25.tinhTien(dungLuong);
                break;
            case "M50":
                tien = mucCuoc.M50.tinhTien(dungLuong);
                break;
            case "M120":
                tien = mucCuoc.M120.tinhTien(dungLuong);
                break;
            case "MAX":
                tien = mucCuoc.MAX.tinhTien(dungLuong);
                break;
            case "MÃX100":
                tien = mucCuoc.MAX100.tinhTien(dungLuong);
                break;
            case "MAX200":
                tien = mucCuoc.MAX200.tinhTien(dungLuong);
                break;
            case "MAXS":
                tien = mucCuoc.MAXS.tinhTien(dungLuong);
                break;
            default:
                tien = 0;
        }
        return tien;
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("Các loại gói cước: M0, M10, M25, M50, M120, MAX, MAX100, M200, MAXS");
            System.out.println("Nhập gói cước mà bạn sử dụng: ");
            
            String goiCuoc = input.readLine();
            System.out.println("Nhập dung lượng(KB): ");
            double dungLuong = Double.parseDouble(input.readLine());
            double tien = tinhTienCuoc(goiCuoc, dungLuong);
            System.out.println("Tiền cước sử dụng là: " + tien);

        } catch (IOException | NumberFormatException | InputMismatchException e) {
            System.out.println(e.getMessage());

        }
    }
    
}
