/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai6InBangCuuChuong {

    /**
     * @param args the command line arguments
     */
    
    public static void inBangCuuChuong(){
        for (int i = 1; i < 10; i++) {
            System.out.print(i + "| ");
            for (int j = 1; j < 10; j++) {
                System.out.print(i * j + "  ");
            }
            
            System.out.print("\n");
        }
        
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Cột|  1  2  3  4  5  6  7  8  9");
        System.out.println("Cửu chương");
        System.out.println("------------------------------------");
        
        try{
        inBangCuuChuong();
        }catch(NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
            
        }
        
    }
    
}
