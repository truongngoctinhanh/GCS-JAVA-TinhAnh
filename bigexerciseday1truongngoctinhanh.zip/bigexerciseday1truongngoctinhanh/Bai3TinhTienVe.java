/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3TinhTienVe {

    /**
     * @param args the command line arguments
     */
    final static int giaA2T = 129000;
    final static int giaA2TL = 128000;
    final static int giaAnLT1 = 249000;
    final static int giaAnLT2 = 218000;
    final static int giaAnT1 = 202000;
    final static int giaAnT2 = 172000;
    final static int giaBnLT1 = 214000;
    final static int giaBnLT2 = 189000;
    final static int giaBnLT3 = 163000;
    final static int giaBnT1= 193000;
    final static int giaBnT2 = 168000;
    final static int giaBnT3 = 146000;
    final static int giaGP = 79000;
    final static int giaNC = 99000;
    final static int giaNCL = 116000;
    final static int giaNM = 129000;
    final static int giaNML = 155000;
    final static int giaNML4V = 171000;
    public static double tinhTienVe(String loaiGhe, int vNguoiLon, int vTreEm, int vNguoiGia ){  
            switch (loaiGhe){
                case "A2T":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaA2T;
                case "A2TL":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaA2TL;
                case "AnLT1":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaAnLT1;
                case "AnLT2":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaAnLT2;
                case "AnT1":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaAnT1;
                case "AnT2":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaAnT2;
                case "BnLT1":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnLT1;
                case "BnLT2":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnLT2;
                case "BnLT3":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnLT3;    
                case "BnT1":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnT1;    
                case "BnT2":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnT2;    
                case "BnT3":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaBnT3;    
                case "GP":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaGP;    
                case "NC":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaNC; 
                case "NCL":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaNCL;    
                case "NM":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaNM;     
               case "NML":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaNML;    
                case "NML4V":
                    return (vNguoiLon + vTreEm * 0.5 + vNguoiGia * 0.75) * giaNML4V; 
                default:
                    throw new AssertionError("Bạn nhập sai loai ghe");
            
        }
    }
    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập vào loại ghế: ");
        try{
        String loaiGhe = input.readLine();
        System.out.print("Nhập vào tổng số vé muốn mua: ");
        int tongVe = Integer.parseInt(input.readLine());
        System.out.print("Số vé dành cho người lớn: ");
        int veNguoiLon = Integer.parseInt(input.readLine());
        System.out.print("Số vé dành cho người trẻ em: ");
        int veTreEm = Integer.parseInt(input.readLine());
        System.out.print("Số vé dành cho người già: ");
        int veNguoiGia = Integer.parseInt(input.readLine());
        
        System.out.println("Tổng số vé: " + tongVe);
        System.out.println("Vé người lớn: " + veNguoiLon + ". Thành tiền: " + " vnđ");
        System.out.println("Vé trẻ em: " + veTreEm + ". Thành tiền: " + " vnđ");
        System.out.println("Vé người già: " + veNguoiGia + ". Thành tiền: " + " vnđ");
        System.out.println("Tổng số tiền: " +tinhTienVe(loaiGhe, veNguoiLon, veTreEm, veNguoiGia)+ " vnđ");
            
        }catch(NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());    
        }
    }
    
}
