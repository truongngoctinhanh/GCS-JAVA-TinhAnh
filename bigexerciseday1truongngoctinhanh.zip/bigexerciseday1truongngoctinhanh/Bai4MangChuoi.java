/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai4MangChuoi {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMang(String[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for(int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " = ");
            mang[i] = input.readLine();
        }
    }
    
    public static void xuatMang(String[]mang){
        for (int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " có nội dung là: " + mang[i] + " và chiều dài là: " + mang[i].length() + "\n");
        }
    } 
    
    public static int timPhanTuDaiNhat(String[]mang){
        int max = 0;
        int i;
        for (i = 1; i < mang.length; i++) {
            max = Math.max(max, mang[i].length());
        }
        return max;
    }
    public static String kiemTraChuoi(String[]mang, String s){
        String t = "Chuỗi s không tồn tại trong mảng";
        for (int i = 0; i < mang.length; i++){
            if(mang[i].contains(s))
                t = "Chuỗi s tồn tại trong mảng tại vị trí " + i;
        }
        return t;
    } 
    
    
    
    public static void sapXepMang(String[] mang){
        Arrays.sort(mang);
        System.out.println("Mảng sau khi đã sắp xếp là: ");
        for (int i = 0; i < mang.length; i++){
            System.out.println(mang[i]);
        }
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập n : ");
        try{
        int n = Integer.parseInt(input.readLine());
        String[] a = new String[n];
        nhapMang(a, n);
        xuatMang(a);
        
        System.out.println(timPhanTuDaiNhat(a));
        
        System.out.println("Nhập vào một chuỗi : ");
        String s = input.readLine();
        System.out.println(kiemTraChuoi(a, s));
        
        
       
        String[] mangMoi = new String[n];
        System.arraycopy(a, 0, mangMoi, 0, a.length);
        xuatMang(mangMoi);
        
        sapXepMang(a);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
        
        
    }
    
}
