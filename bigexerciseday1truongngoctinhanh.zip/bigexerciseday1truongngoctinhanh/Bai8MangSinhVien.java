/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.kiemTraChuoi;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.nhapMang;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.sapXepMang;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.timPhanTuDaiNhat;
import static bigexerciseday1truongngoctinhanh.Bai4MangChuoi.xuatMang;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai8MangSinhVien {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    
        Random random = new Random();
        for(int i = 0; i < n; i++){
            mang[i] = random.nextInt(100);            
        }
    }
    public static void xuatMang(int[] mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static void thongKe(int[] mang){
        String s1 = "";
        String s2 = "";
        String s3 = "";
        String s4 = "";
        String s5 = "";
        String s6 = "";
        String s7 = "";
        String s8 = "";
        String s9 = "";
        String s10 = "";
        for (int i = 0; i < mang.length; i++){
            if(mang[i] >= 0 && mang[i] < 10){
                s1 = s1 + "*";
            }else if(mang[i] < 20){    
                s2 = s2 + "*";
            }else if(mang[i] < 30){    
                s3 = s3 + "*";
            }else if(mang[i] < 40){    
                s4 = s4 + "*";
            }else if(mang[i] < 50){    
                s5 = s5 + "*"; 
            }else if(mang[i] < 60){    
                s6 = s6 + "*";
            }else if(mang[i] < 70){    
                s7 = s7 + "*";
            }else if(mang[i] < 80){    
                s8 = s8 + "*";
            }else if(mang[i] < 90){    
                s9 = s9 + "*";
            }else if(mang[i] <= 100){    
                s10 = s10 + "*"; 
            }else 
                System.out.println("");
        }
        System.out.println("0 - 9: " + s1);
        System.out.println("10 - 19: " + s2);
        System.out.println("20 - 29: " + s3);
        System.out.println("30 - 39: " + s4);
        System.out.println("40 - 49: " + s6);
        System.out.println("50 - 59: " + s6);
        System.out.println("60 - 69: " + s7);
        System.out.println("70 - 79: " + s8);
        System.out.println("80 - 89: " + s9);
        System.out.println("90 - 100: " + s10);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập n : ");
        try{
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];
        nhapMang(a, n);
        xuatMang(a);
        thongKe(a);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
