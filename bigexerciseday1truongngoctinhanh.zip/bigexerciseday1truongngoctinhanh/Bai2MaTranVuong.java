/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2MaTranVuong {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMaTran(int[][] mang) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("Nhập phần tử ở dòng " + i + " cột " + j + " = ");
                mang[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }
    
    public static void xuatMaTran(int[][] mang){
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("\t" + mang[i][j]);
            }
            System.out.print("\n");
        }        
    } 
    
    public static void timPhanTuLonNhat(int[][] mang){
        for (int i = 0; i < mang.length; i++) {
            int soLN = mang[i][0];
            for(int j= 0;j < mang[i].length;j++){
                if(mang[i][j] > soLN){
                    soLN = mang[i][j];
                    
                }
            }
            System.out.println("Số lớn nhất của dòng " + i+ " là: " + soLN);
            
        } 
    }
    public static void timPhanTuNhoNhat(int[][] mang){
        
        for (int i = 0; i < mang.length; i++) {
            int soNN = mang[i][0];
            for(int j= 0;j < mang[i].length;j++){
                if(mang[i][j] < soNN){
                    soNN = mang[i][j];
                    
                }
            }
            System.out.println("Số nhỏ nhất của dòng " + i + " là: " + soNN);
            
        }        
    }
    
    public static void inMatTranX(int[][] mang, int x){
        for (int i = 0; i < mang.length; i++) {
            mang[i][i] = x;
            mang[i][mang.length - 1 - i] = x;
        }
    }
    
    
    public static int timPhanTuAmLonNhat(int[][] mang){
        int soLN = 0;
        for (int i = 0; i < mang.length; i++) {
            for(int j=0;j<mang[i].length;j++){
                if (soLN < mang[i][j] && mang[i][j] > mang[i][j+ 1]){
                    soLN = mang[i][j];
                }
                
            }
        } 
        return soLN;
    }
    
    public static int timPhanTuDuongNhoNhat(int[][] mang){
        int soNhoNhat = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] >= 0 && mang[i][j] > soNhoNhat) {
                    soNhoNhat = mang[i][j];
                }
            }
        }
        return soNhoNhat;
    }
    
    public static int demPhanTuDuong(int[][] mang){
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if ((i <= j) && (mang[i][j] >= 0))
                        dem++;
            }
        }
        return dem;
    }
    
    public static int demPhanTuAmChiaHetCho2Va3(int[][] mang){
        int dem = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if ((mang[i][j] < 0 && mang[i][j] % 2 == 0) && (mang[i][j] % 3 == 0))
                        dem++;
            }
        }
        return dem;
    }
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập vào dòng và cột của ma trận m = ");
        try{
        int n = Integer.parseInt(input.readLine());
        int[][] a = new int[n][n];
        int[][] b = new int[n][n];
        System.out.println("Nhập ma trận vuông a: ");
        nhapMaTran(a);
        System.out.println("Ma trận vuông a đã nhâp là: ");
        xuatMaTran(a);
        timPhanTuLonNhat(a);
        timPhanTuNhoNhat(a);
        
        System.out.print("Nhập vào số nguyên x = ");
        int x = Integer.parseInt(input.readLine());
        
        inMatTranX(a, x);        
        System.out.println("Ma trận vuông a là: ");
        xuatMaTran(a);
        
        //System.out.println("Phần tử âm lớn nhất trong mảng " + timPhanTuAmLonNhat(a));
        //System.out.println("Phần tử dương nhỏ nhất trong mảng " + timPhanTuDuongNhoNhat(a));
        
        System.out.println("Có " + demPhanTuDuong(a) + " phần tử có giá trị dương nằm ở tam giác phía trên đường chéo chính" );
        System.out.println("Có " + demPhanTuAmChiaHetCho2Va3(a) + " phần tử có giá trị âm chia hết cho 2 và 3");
        
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());    
        }
    }
    
}
