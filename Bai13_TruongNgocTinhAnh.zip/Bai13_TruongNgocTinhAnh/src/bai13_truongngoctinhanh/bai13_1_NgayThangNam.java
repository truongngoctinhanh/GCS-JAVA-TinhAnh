/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13_truongngoctinhanh;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author hocvien
 */
public class bai13_1_NgayThangNam {

    /**
     * @param args the command line arguments
     */
    
    public static void xuatNgayThangNam(){
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Calendar toDay = Calendar.getInstance();
        System.out.println("Hôm nay là ngày: " + df.format(toDay.getTime()));
        if(toDay.get(Calendar.DAY_OF_WEEK) != 1){
            System.out.println("Thứ: " + toDay.get(Calendar.DAY_OF_WEEK));
        }else
            System.out.println("Chủ nhật");
        
        System.out.println("Là tuần thứ " + toDay.get(Calendar.WEEK_OF_YEAR) + " trong năm " + toDay.get(Calendar.YEAR));
        toDay.add(Calendar.DAY_OF_WEEK, 7);
        System.out.println("Sau 1 tuần sẽ là ngày: " + df.format(toDay.getTime()));
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        xuatNgayThangNam();
    }
}
