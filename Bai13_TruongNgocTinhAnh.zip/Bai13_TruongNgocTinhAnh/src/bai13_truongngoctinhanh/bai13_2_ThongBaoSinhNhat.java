/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class bai13_2_ThongBaoSinhNhat {

    /**
     * @param args the command line arguments
     */
    
    public static void kiemTraNgay(String ngay){
        String regexp = ("([0]?[\\d]|[12][\\d]|3[01])[/]([0]?[\\d]|1[0-2])[/]([012]?[\\d]?[\\d]?[\\d])");
        Pattern pattern = Pattern.compile(regexp);
        Matcher m = pattern.matcher(ngay);
        boolean b = m.matches();
        if(b == true){
            System.out.println("Bạn đã nhập ngày hợp lệ");
        }else
            System.out.println("Bạn đã nhập ngày không hợp lệ");
    }
    
    public static void sinhNhat(String ngay){
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date d = new Date();
        System.out.println("Hôm nay là ngày: " + df.format(d));
        System.out.println("Ngày sinh nhật của bạn là: " + df.format(new Date(ngay)));
        
        String[] days = ngay.split("/");
        LocalDate today = LocalDate.now();
        LocalDate bd = LocalDate.of(today.getYear(), Integer.parseInt(days[1]),Integer.parseInt(days[0]));
        Period p = Period.between(today, bd);
        if(p.getMonths() == 0 && p.getDays() == 0){
            System.out.println("Chúc mừng sinh nhật của bạn !");
        }else if(p.getMonths() > 0 || (p.getMonths() == 0 && p.getDays() > 0)){
            System.out.println("Vui lòng đợi thêm nhé !");
        }else if(p.getDays() < 0){
            System.out.println("Hẹn sinh nhật năm sau nha !");
        }
    } 
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập vào ngày sinh của bạn ");
        try{
        String ngaySinh = input.readLine();
        
        kiemTraNgay(ngaySinh);
        sinhNhat(ngaySinh);        
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
