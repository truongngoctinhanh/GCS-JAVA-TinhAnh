/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_3_PhuongThucBai6_2 {

    /**
     * @param mang
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for(int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " = ");
            mang[i] = Integer.parseInt(input.readLine());
        }
    }
    
    public static void xuatMang(int[]mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static String timX(int[] mang, int x){
        String t = x + " không tồn trong mảng";
        for(int i = 0; i <= mang.length - 1; i++){
            if(mang[i] == x){
                t = x + " xuất hiện trong mảng tại vị trí " + i;
                break;
            }        
        }
        return t;
    }  
     
    
    public static String kiemTraX(int[] mang, int x){
        String t = x + " lớn hơn tất cả các số trong mảng";
        for(int i = 0; i <= mang.length - 1; i++){
            if(mang[i] > x){
                t = x + " không lớn hơn tất cả các số trong mảng";
                break;
            }
        }
        return t;
    }


    public static void kiemTraX1 (int[] arr, int x){
        System.out.print("Tất cả các số lớn hơn " + x + " là ");
        for(int i = 0; i <= arr.length - 1; i++){            
            if(arr[i] > x){
                System.out.print(arr[i] + " ");                
            }
        }
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];
        
        System.out.print("Nhập x: ");
        int x = Integer.parseInt(input.readLine());
        
        System.out.print("Nhập mảng a: ");
        nhapMang(a, n);
        System.out.print("Xuất mảng a: ");
        xuatMang(a);

        System.out.println(timX(a, x));
        System.out.println(kiemTraX(a, x));
        kiemTraX1(a, x);

    }
}
