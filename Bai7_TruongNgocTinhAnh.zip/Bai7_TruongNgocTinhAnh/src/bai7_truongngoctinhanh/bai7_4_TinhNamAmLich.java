/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_4_TinhNamAmLich {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void tinhCanChi(int n){
        int c = n % 10;
        int ch = n % 12;
        String can = "";
        String chi = "";
        
        switch(c){
            case 0: can = "Canh";
                break;
            case 1: can = "Tân";
                break;
            case 2: can = "Nhâm";
                break; 
            case 3: can = "Quý";
                break;
            case 4: can = "Giáp";
                break;
            case 5: can = "Ất";
                break;
            case 6: can = "Bính";
                break;
            case 7: can = "Đinh";
                break;
            case 8: can = "Mậu";
                break;
            case 9: can = "Kỷ";
                break;
        }
        
        switch(ch){
            case 0: chi = "Thân";
                break;
            case 1: chi = "Dậu";
                break;
            case 2: chi = "Tuất";
                break; 
            case 3: chi = "Hợi";
                break;
            case 4: chi = "Tý";
                break;
            case 5: chi = "Sửu";
                break;
            case 6: chi = "Dần";
                break;
            case 7: chi = "Mão";
                break;
            case 8: chi = "Thìn";
                break;
            case 9: chi = "Tỵ";
                break;
            case 10: chi = "Ngọ";
                break;
            case 11: chi = "Mùi";
                break;
        }
        
        System.out.println(can + " " + chi);
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập vào năm sinh: ");
        int n = Integer.parseInt(input.readLine());
        
        tinhCanChi(n);
    }
}
