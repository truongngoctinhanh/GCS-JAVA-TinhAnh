/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_2_PhuongThucBai5_2 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static double TinhA (int n, int x){
        double t1 = (x * x + x + 1);
        double t2 = (x * x - x + 1);
        double s1 = 1;
        double s2 = 1;
        double s = 0;
        for(int i = 1; i <= n; i++){
            s1 = s1 * t1;
            s2 = s2 * t2;
            s = s1 + s2;
        } 
        return s;
    }
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.print("Nhập x: ");
        int x = Integer.parseInt(input.readLine());        
        System.out.println("S = (x * x + x + 1) mũ n + (x * x - x + 1) mũ n = " + TinhA(n, x));
    }
    
}
