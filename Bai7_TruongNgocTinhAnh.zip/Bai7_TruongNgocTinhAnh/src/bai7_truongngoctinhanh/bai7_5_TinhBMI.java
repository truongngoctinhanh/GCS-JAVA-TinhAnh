/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_5_TinhBMI {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void tinhBMI(double c, double n){
        String t = "";
        double bMI = n / (c * c);
        if(bMI < 18.5){
            t = "Gầy";
        }else if(bMI >= 25){
            t = "Thừa cân";
        }else{
            t = "Bình thường";
        }
        System.out.println("Chỉ số BMI của cơ thể bạn là: " + bMI + "\n" + t);
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập vào chiều cao: ");
        double c = Double.parseDouble(input.readLine());
        System.out.print("Nhập vào cân nặng: ");
        double n = Double.parseDouble(input.readLine());
        
        tinhBMI(c, n);
    }
    
}
