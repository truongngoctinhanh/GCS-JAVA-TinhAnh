/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_7_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_7_PhuongThucBai6_5 {

    /**
     * @param mang
     * @param args the command line arguments
     * @throws java.io.IOException
     */
   
    public static void nhapMang(int[][] mang) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("Nhập phần tử ở dòng " + i + " cột " + j + " = ");
                mang[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }
    
    public static void xuatMang(int[][] mang){
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("\t" + mang[i][j]);
            }
            System.out.print("\n");
        }        
    } 
    
    public static void demChanLe(int[][] mang){
        int dem1 = 0;
        int dem2 = 0;
        for (int i = 0; i < mang.length; i++){
            for (int j = 0; j < mang[i].length; j++){
                if(mang[i][j] % 2 == 0){
                    dem1++;
                }else{
                    dem2++;
                }
            }
        }
        System.out.println("Trong mảng a có " + dem1 + " phần tử chẳn");
        System.out.println("Trong mảng a có " + dem2 + " phần tử lẻ");
    }
    
    public static void tBChanLe(int[][] mang){
        int tong1 = 0;
        int tong2 = 0;
        int dem1 = 0;
        int dem2 = 0;
        for (int i = 0; i < mang.length; i++){
            for (int j = 0; j < mang[i].length; j++){
                if(mang[i][j] % 2 == 0){
                    tong1 += mang[i][j];
                    dem1++;
                }else{
                    tong2 += mang[i][j];
                    dem2++;
                }
            }
        }
        double tb1 = tong1/dem1;
        double tb2 = tong2/dem2;
        System.out.println("Giá trị trung bình của các phần tử chẳn trong mảng a là: " + tb1);
        System.out.println("Giá trị trung bình của các phần tử lẻ trong mảng a là: " + tb2);
    }
    
    public static int pTlonNhat(int[][] mang){
        int soLN = mang[0][0];
        for (int i = 0; i < mang.length; i++){
            for (int j = 0; j < mang[i].length; j++){
                if(soLN < mang[i][j]){
                    soLN = mang[i][j] ;
                }
            }
        }
        return soLN;
    }    
    
    public static String timViTriLonNhat(int[][] mang) {
        String t = "Vị trí của số lớn nhất là: dòng 0 cột 0";
        int soLN = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] > soLN) {
                    soLN = mang[i][j];
                    t = "Vị trí của số lớn nhất là: dòng " + i + " cột " + j;
                }
            }
        }
        return t;
    }
    
    public static String timViTriNhoNhat(int[][] mang) {
        String t = "Vị trí của số nh nhất là: dòng 0 cột 0";
        int soNN = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < soNN) {
                    soNN = mang[i][j];
                    t = "Vị trí của số nhỏ nhất là: dòng " + i + " cột " + j;
                }
            }
        }
        return t;
    }
    public static int pTNhoNhat(int[][] mang){
        int soNN = mang[0][0];
        for (int i = 0; i < mang.length; i++){
            for (int j = 0; j < mang[i].length; j++){
                if(soNN > mang[i][j]){
                    soNN = mang[i][j];
                }
            }
        }
        return soNN;
    }
    
    public static int demPhantu(int[][] mang, int a){
        int dem = 0;
        for (int i = 0; i < mang.length; i++){
            for (int j = 0; j < mang[i].length; j++){
                if(mang[i][j] == a){
                    dem++;
                }
            }
        }
        return dem;
    }
        
    public static int demPhantuNhieuNhat(int[][] mang){
       
        int dem = 0;
        int tam = 0;
        int tam1 = 0;
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                dem = demPhantu(mang, mang[i][j]);
                if(dem > tam){
                    tam = dem;
                    tam1 = mang[i][j];
                }
            }
        }
        return tam1;
    }
    
    public static String timPhanTuAm(int[][] mang) {
        String t = "Mảng a không chứa phần tử âm";
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if (mang[i][j] < 0){
                    t = "Mảng a chứa phần tử âm";
                }
            }
        }
        return t;
    }
    
    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập số cột: ");
        int m = Integer.parseInt(input.readLine());
        System.out.println("Nhập số dòng: ");
        int n = Integer.parseInt(input.readLine());
        
        int[][] a = new int[n][m]; 
        
        nhapMang(a);
        xuatMang(a);
        demChanLe(a);
        tBChanLe(a);
        System.out.println("Phần tử lớn nhất trong mảng a là: " + pTlonNhat(a));
        System.out.println(timViTriLonNhat(a));
        System.out.println("Phần tử nhỏ nhất trong mảng a là: " + pTNhoNhat(a));
        System.out.println(timViTriNhoNhat(a));
        System.out.println("Phần tử có số lần xuất hiện nhiều nhất trong mảng a là: " +demPhantuNhieuNhat(a));
        System.out.println(timPhanTuAm(a));
    }
    
}
