/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_7_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai7_7_PhuongThucBai6_1 {

    /**
     * @param mang
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        Random random = new Random();
        for(int i = 0; i < n; i++){
            mang[i] = random.nextInt(n);            
        }
    }
    
    public static void xuatMang(int[] mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static int tong(int[] mang){
        int tong = 0;
        for (int i = 0; i < mang.length; i++){
            tong += mang[i];
        }
        return tong;
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];
        
        nhapMang(a, n);
        xuatMang(a);
        System.out.println("Tổng = " + tong(a));
        
    }
}
