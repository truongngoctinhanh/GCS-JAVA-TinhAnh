/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_8_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_8_PhuongThucBai5_7 {

    /**
     * @param args the command line arguments
     */
    
    public static int doiThapPhan (String n){
        
        int re = 0;
        int tmp = n.length() - 1;
        for (int i = 0; i < n.length(); i++){
            int num= Integer.parseInt(n.charAt(i)+"");
            re += num * Math.pow(2, tmp);
            tmp--;
        }
        return re;
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập số nhị phân: ");
        String n = input.readLine();
        System.out.println("Số nhị phân " + n + " chuyển sang thập phân = " +doiThapPhan(n));
    }
}
