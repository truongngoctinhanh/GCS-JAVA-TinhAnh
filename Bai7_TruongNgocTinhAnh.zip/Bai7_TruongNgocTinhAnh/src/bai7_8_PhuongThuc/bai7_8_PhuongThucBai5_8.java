/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_8_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_8_PhuongThucBai5_8 {

    /**
     * @param args the command line arguments
     */
    
    public static void inBangCuuChuong(int ts, int ds){
        if(ts <= ds){
            for(int i = 1; i < 10; i++){             
                for(int j = ts; j <= ds; j++){                
                    System.out.print(j + " x " + i + " = " + j*i+"\t");            
                }
            System.out.print("\n");    
            }
        }else{
            System.out.println("");
        }  
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("*****************************************************");
        System.out.println("In bảng cửu chương");
        System.out.println("*****************************************************");
        System.out.print("Từ số: ");
        int ts = Integer.parseInt(input.readLine());
        System.out.print("Đến số: ");
        int ds = Integer.parseInt(input.readLine());
        System.out.println("-----------------------------------------------------");
        System.out.println("Bảng cửu chương từ " + ts + " đến " + ds);
        inBangCuuChuong(ts, ds);
    }
    
}
