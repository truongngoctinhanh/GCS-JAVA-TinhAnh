/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_6_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_6_PhuongThucBai5_4 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void tinhABC(int n){
        double a = 0;
        double b = 0;
        double c = 1;
        for (int i = 1; i <= n; i++){
            if (i % 2 == 1){
                a = a + i; 
            }else{
                b = b + i;
            }
            c = c * i;
        }
        System.out.println("Ket qua A = " + String.format("%.0f", a));
        System.out.println("Ket qua B = " + String.format("%.0f", b));
        System.out.println("Ket qua C = " + String.format("%.0f", c));
    }
    
    public static void tinhD(int n){
        double d = 1;
        for (int i = 1; i <= n; i++){
            if (i % 3 == 0){
                d = d * i; 
            }
        }
        System.out.println("Ket qua D = " + String.format("%.0f", d));
    }
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        
        tinhABC(n);
        tinhD(n);
    }
}
