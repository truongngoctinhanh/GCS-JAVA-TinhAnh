/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_6_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_6_PhuongThucBai5_6 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void doiNhiPhan1 (int n){
        String s= "";
        for(; n > 0;n = n / 2){            
            s += n%2;            
        }
        for(int j = s.length() - 1; j >= 0; j--){
            String re= String.valueOf(s.charAt(j));
            System.out.print(re);
        }
    }    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        
        System.out.print("Số thập phân " + n + " chuyển sang nhị phân = " );      
        doiNhiPhan1(n);
    }
    
}
