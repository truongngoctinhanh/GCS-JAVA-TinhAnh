/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_9_PhuongThuc;

import static bai7_9_PhuongThuc.bai7_9_PhuongThucBai6_3.nhapMang;
import static bai7_9_PhuongThuc.bai7_9_PhuongThucBai6_3.xuatMang;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_9_PhuongThucBai6_4 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for(int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " = ");
            mang[i] = Integer.parseInt(input.readLine());
        }
    }
    
    public static void xuatMang(int[]mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static String timCSChiaHet(int[] mang){
        
        String t = "";
        for(int i = 0; i < mang.length - 1; i++){
            for(int j = i +1; j < mang.length; j++){
                if(mang[i] % mang[j] == 0 ||mang[j] % mang[i] == 0)
                    t += mang[i] + " & " + mang[j] + "\n";
            }
        }
        return t;
    }
    
    public static String timCSGap2(int[] mang){
        
        String t = "";
        for(int i = 0; i < mang.length - 1; i++){
            for(int j = i +1; j < mang.length; j++){
                if(mang[i] / mang[j] == 2 ||mang[j] / mang[i] == 2)
                    t += mang[i] + " & " + mang[j] + "\n";
            }
        }
        return t;
    }
    
    public static String timCSTong(int[] mang){
        
        String t = "";
        for(int i = 0; i < mang.length - 1; i++){
            for(int j = i +1; j < mang.length; j++){
                if(mang[i] + mang[j] == 8 ||mang[j] + mang[i] == 8)
                    t += mang[i] + " & " + mang[j] + "\n";
            }
        }
        return t;
    }
   
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];  
        
        nhapMang(a, n);
        xuatMang(a);
        
        System.out.println("Cặp số có quan hệ chia hết là\n" + timCSChiaHet(a));
        System.out.println("Cặp số có quan hệ số này gấp 2 lần số kia là\n" + timCSGap2(a));
        System.out.println("Cặp số có tổng 2 số bằng 8 là\n" + timCSTong(a));
      
    }
    
}
