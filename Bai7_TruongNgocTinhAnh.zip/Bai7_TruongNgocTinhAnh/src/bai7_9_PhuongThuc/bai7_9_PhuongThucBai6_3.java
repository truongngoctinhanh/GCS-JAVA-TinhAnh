/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_9_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7_9_PhuongThucBai6_3 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void nhapMang(int[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for(int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " = ");
            mang[i] = Integer.parseInt(input.readLine());
        }
    }
    
    public static void xuatMang(int[]mang){
        for (int i = 0; i < mang.length; i++)  {
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static String kTTangDan(int[] mang) {
        String t = "Mảng a có sắp xếp tăng dần";
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] > mang[i + 1]) {
                t = "Mảng a không có sắp xếp tăng dần";
            }
        }
        return t;
    }

    public static String kTGiamDan(int[] mang) {
        String t = "Mảng a có sắp xếp giảm dần";
        for (int i = 0; i < mang.length - 1; i++) {
            if (mang[i] < mang[i + 1]) {
                t = "Mảng a không có sắp xếp giảm dần";
            }
        }
        return t;
    }

    public static int kTPTDauTien(int[] mang) {
        
        for (int value : mang) {
            if (value % 10 == 6) {
                return value;
            }
        }
        return 0;
    }
    
    public static void xuatKTPTDauTien(int[] mang){
        if (kTPTDauTien(mang) == 0) {
            System.out.println("Phần tử cần tìm không tồn tại trong mang a");
        } else {
            System.out.println("Phần tử cần tìm: " + kTPTDauTien(mang));
        }
    }
    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        int[] a = new int[n];  
        
        nhapMang(a, n);
        xuatMang(a);
        
        System.out.println(kTTangDan(a));
        System.out.println(kTGiamDan(a));
        xuatKTPTDauTien(a);
        
    }
    
    
}
