/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_9_PhuongThuc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai7_9_PhuongThucBai6_6 {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMangA(int[][] mang){
        Random random = new Random();
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                mang[i][j] = random.nextInt(20);
            }
        }
    }
    
    public static void nhapMangB(int[][] mang) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("Nhập phần tử ở dòng " + i + " cột " + j + " = ");
                mang[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }
    
    public static void xuatMang(int[][] mang){
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                System.out.print("\t" + mang[i][j]);
            }
            System.out.print("\n");
        }        
    } 
    
    public static int tongDCChinh(int[][] mang){
        int tong = 0;
        for (int i = 0; i < mang.length; i++) {
            tong += mang[i][i];
        } 
        return tong;
    } 
    
    public static int timLonNhat(int[][] mang){
        int soLN = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            if(mang[i][i] > soLN){
                soLN = mang[i][i];
            }
        } 
        return soLN;
    }
    
    public static int timNhoNhat(int[][] mang){
        int soNN = mang[0][0];
        for (int i = 0; i < mang.length; i++) {
            if(mang[i][i] < soNN){
                soNN = mang[i][i];
            }
        } 
        return soNN;
    }
    
    public static int ktSNT(int n) {
        int i;
        if (n == 1 || n == 0) {
            return 0;
        }
        for (i = 2; i <= (int) Math.sqrt(n); i++) {
            if (n % i == 0) {
                return 0;
            } else {
                return 1;
            }
        }
        return 1;
    }
    
    public static void giaTriNguyenTo(int[][] mang){
        for (int i = 0; i < mang.length; i++) {
            for (int j = 0; j < mang[i].length; j++) {
                if(ktSNT(mang[i][j]) == 1){
                System.out.println("Số nguyên tố " + mang[i][j] + " ở vị trí dòng " + i + " cột " + j);
                }
            } 
        }
    }
    
    public static String kiemTraDoiXung(int[][] mang){
        String t = "Mảng b không đối xứng qua đường chéo chính";
        for (int i = 0; i < mang.length; i++) {
            for (int j = i + 1; j < mang[i].length; j++) {
                if(mang[i][j] == mang[j][i]){
                    t= "Mảng b đối xứng qua đường chéo chính";
                    break;
                }
            } 
        }
        return t;
    }
    
    public static void xuatMangC(int[][] mangc, int[][] manga, int[][] mangb){
        for (int i = 0; i < mangc.length; i++) {
            for (int j = 0; j < mangc[i].length; j++) {
                mangc[i][j] = manga[i][j] + mangb[i][j];
                System.out.print("\t" + mangc[i][j]);
            }
            System.out.print("\n");
        }
    }
    
    public static void kiemTraCotKTăng(int[][] mang, int k){
        String t = "Cột " + k + " trong mảng c có sắp xếp tăng dần";
        for(int i = 0; i < mang.length-1; i++){
                if(mang[i][k] > mang[i + 1][k]){
                    t = "Cột " + k + " trong mảng c không sắp xếp tăng dần";
            } 
        }
        System.out.println(t);
    }
    
    public static void kiemTraCotKGiam(int[][] mang, int k){
        String t = "Cột " + k + " trong mảng c có sắp xếp giảm dần";
        for(int i = 0; i < mang.length - 1; i++){
                if(mang[i][k] <  mang[i + 1][k]){
                    t = "Cột " + k + " trong mảng c không sắp xếp giảm dần";
            } 
        }
        System.out.println(t);
    }
    
    
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập vào dòng và cột của ma trận m = ");
        int m = Integer.parseInt(input.readLine());
        int[][] a = new int[m][m]; 
        
        System.out.println("Nhập mảng a: ");
        nhapMangA(a);
        System.out.println("Mảng a đã nhâp: ");        
        xuatMang(a);
        
        System.out.println("Tổng các giá trị trên đường chéo chính của ma trận vuông a = " + tongDCChinh(a));
        System.out.println("Giá trị lớn nhất trên đường chéo chính của ma trận vuông a = " + timLonNhat(a));
        System.out.println("Giá trị nhỏ nhất trên đường chéo chính của ma trận vuông a = " + timNhoNhat(a));
        giaTriNguyenTo(a);
        
        int[][] b = new int[m][m];
        System.out.println("Nhập mảng b: ");
        nhapMangB(b);
        System.out.println("Mảng b đã nhâp: ");
        xuatMang(b);
        System.out.println(kiemTraDoiXung(b));
        
        int[][] c = new int[m][m];        
        System.out.println("Mảng c đã nhâp: ");
        xuatMangC(c, a, b);
        
        System.out.print("Nhâp vào chỉ số cột cần kiểm tra k = ");
        int k = Integer.parseInt(input.readLine());
        kiemTraCotKTăng(c, k);
        kiemTraCotKGiam(c, k);
    }
}
