/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5_10_TruongNgocTinhAnh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_10_1_TinhS_While {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */

public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.println("Nhập x: ");
        double x = Double.parseDouble(input.readLine());
        double t = (x * x + 1);
        double s = 1;
        int i = 1;
        while (i <= n){
            s = s * t;
            i++;
            } 
        System.out.println("S = (x * x + 1) mũ n = " + s);
    }
    
}
