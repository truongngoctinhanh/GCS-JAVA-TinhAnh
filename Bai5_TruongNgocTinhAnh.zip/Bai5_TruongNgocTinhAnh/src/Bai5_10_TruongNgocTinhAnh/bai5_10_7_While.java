/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5_10_TruongNgocTinhAnh;

import static bai5_truongngoctinhanh.bai5_7_DoiNhiPhanSangThapPhan.doiThapPhan;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_10_7_While {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập số nhị phân: ");
        String n = input.readLine();
        System.out.println(doiThapPhan(n));
    }
    
    public static int doiThapPhan (String n){
        
        int re = 0;
        int tmp = n.length() - 1;
        int i = 0;
        while(i < n.length()){
            int num= Integer.parseInt(n.charAt(i)+"");
            re += num * Math.pow(2, tmp);
            tmp--;
            i++;
        }
        return re;
    }
    
}
