/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5_10_TruongNgocTinhAnh;

import static bai5_truongngoctinhanh.bai5_3_KiemTraSoNguyenTo.ktSNT;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_10_3_While {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        if (n > 0) {
            if (ktSNT(n) == 1) {
                System.out.println(n + " là số nguyên tố");
            } else {
                System.out.println(n + " không là số nguyên tố");
            }
        }
    }
    
    public static int ktSNT(int n) {
        int i = 2;
        if (n == 1) {
            return 0;
        }
        int m = n/2;
        while (i < m) {
            if (n % i == 0) {
                return 0;
            } else {
                return 1;
            }
        }
        return 1;
    }
    
}
