/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5_10_TruongNgocTinhAnh;

import static bai5_truongngoctinhanh.bai5_9_TinhGiaiThua.GiaThua1;
import static bai5_truongngoctinhanh.bai5_9_TinhGiaiThua.GiaThua2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_10_9_While {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        GiaiThua1(n);
        GiaiThua2(n);
    }
    
    public static void GiaiThua1(int n){
        int i = 1;
        int gt = 1;
        while (i <= n){
            gt = gt * i;  
            i++;
        }
        System.out.print(n + "! = ");
        i = 1;
        while (i < n){             
            System.out.print(i + " x "); 
            i++;
        }                
        System.out.print(n); 
        System.out.print(" = " + gt);
    }
    
    public static void GiaiThua2(int n){
        int i = 1;
        int gt = 1;
        while (i <= n){
            if(i % 2 == 0){
                gt = gt * i;                
            } 
            i++;
        }
        System.out.print("\n" + n + "!! = ");
        i = 1;
        while (i < n){ 
            if(i % 2 == 0){
                System.out.print(i + " x ");                 
            } 
            i++;
        }
        System.out.print(n); 
        System.out.print(" = " + gt);
    }    
}
