/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai5_10_TruongNgocTinhAnh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_10_8_While {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("*****************************************************");
        System.out.println("In bảng cửu chương");
        System.out.println("*****************************************************");
        System.out.print("Từ số: ");
        int ts = Integer.parseInt(input.readLine());
        System.out.print("Đến số: ");
        int ds = Integer.parseInt(input.readLine());
        System.out.println("-----------------------------------------------------");
        int i = 1;        
        if(ts <= ds){
            while(i < 10){ 
                int j = ts;
                while(j <= ds){                
                    System.out.print(j + " x " + i + " = " + j*i+"\t"); 
                    j++;                     
                }                
               i++;                       
            System.out.print("\n");    
            }
        }else{
            System.out.println("");
        }  
    }
    
}
