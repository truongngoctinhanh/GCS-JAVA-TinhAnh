/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author anhtruong
 */
public class bai5_1_TinhS {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.println("Nhập x: ");
        double x = Double.parseDouble(input.readLine());
        double t = (x * x + 1);
        double s = 1;
        for(int i = 1; i <= n; i++){
            s = s * t;
            } 
        System.out.println("S = (x * x + 1) mũ n = " + s);
    }
       
}
