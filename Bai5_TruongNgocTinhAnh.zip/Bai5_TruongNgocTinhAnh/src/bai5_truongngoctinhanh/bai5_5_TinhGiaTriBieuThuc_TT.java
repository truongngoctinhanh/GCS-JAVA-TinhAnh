/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_5_TinhGiaTriBieuThuc_TT {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        double e = 0;
        for(int i = 1; i <= n; i++){
            if(ktSNT(i) == 1){
                e = e + i;
            }
        }
        System.out.println("Ket qua E = " + String.format("%.0f", e));
    }
    
    public static int ktSNT(int n) {
        int i;
        if (n == 1) {
            return 0;
        }
        for (i = 2; i <= (int) Math.sqrt(n); i++) {
            if (n % i == 0) {
                return 0;
            } else {
                return 1;
            }
        }
        return 1;
    }
    
}
