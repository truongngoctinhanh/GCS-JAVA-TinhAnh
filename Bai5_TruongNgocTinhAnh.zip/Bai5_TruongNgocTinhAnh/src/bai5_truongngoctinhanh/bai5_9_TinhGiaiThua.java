/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_9_TinhGiaiThua {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhập n: ");
        int n = Integer.parseInt(input.readLine());
        GiaThua1(n);
        GiaThua2(n);
    }    
    public static void GiaThua1(int n){
        int gt = 1;
        for (int i = 1; i <= n; i++){
            gt = gt * i;            
        }
        System.out.print(n + "! = ");
        for (int i = 1; i < n; i++){             
            System.out.print(i + " x ");          
        }
        System.out.print(n); 
        System.out.print(" = " + gt);

    }
    
    public static void GiaThua2(int n){
        int gt = 1;
        for (int i = 1; i <= n; i++){
            if(i % 2 == 0){
                gt = gt * i;  
            }
                      
        }
        System.out.print("\n" + n + "!! = ");
        for (int i = 1; i < n; i++){ 
            if(i % 2 == 0){
                System.out.print(i + " x ");  
            }        
        }
        System.out.print(n); 
        System.out.print(" = " + gt);

    }
}
    
