/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5_8_InBangCuuChuong {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("*****************************************************");
        System.out.println("In bảng cửu chương");
        System.out.println("*****************************************************");
        System.out.print("Từ số: ");
        int ts = Integer.parseInt(input.readLine());
        System.out.print("Đến số: ");
        int ds = Integer.parseInt(input.readLine());
        System.out.println("-----------------------------------------------------");
        if(ts <= ds){
            for(int i = 1; i < 10; i++){             
                for(int j = ts; j <= ds; j++){                
                    System.out.print(j + " x " + i + " = " + j*i+"\t");            
                }
            System.out.print("\n");    
            }
        }else{
            System.out.println("");
        }  
      
        
    }
    
}
