/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part1_truongngoctinhanh;

import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.chieuDai;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.noiChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.soSanhChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.taoChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.timVTDauTien;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai11_2_XuLyStringBuilder {

    /**
     * @param args the command line arguments
     */
    
    public static void chieuDai(String s){
        int le = s.length();
        System.out.println("Chiều dài của chuỗi " + s + " là: " + le);
    }
    
    public static void xuLyChuoi(String sb1, String sb2, String sb3, String sb4, int x, int vtd, int vtc){
        
        StringBuilder sb = new StringBuilder();
        System.out.println("Nối chuỗi sb1 vào sau chuỗi sb thành chuỗi: " + sb.append(sb1));
        System.out.println("Chèn chuỗi sb2 vào chuỗi sb tại vị trí " + x + " tạo thành chuỗi: " + sb.insert(x, sb2));
        System.out.println("Xóa nội dung trong chuỗi sb từ vị trí " + vtd + " đến vị trí " + vtc + " thành chuỗi: " + sb.delete(vtd, vtc));
        System.out.println("Chuỗi sb sau khi đảo ngược là: " + sb.reverse());
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập chuỗi sb: ");
        try{
        String sb = input.readLine();
        System.out.println("Nhập chuỗi sb1: ");
        String sb1 = input.readLine();
        System.out.println("Nhập chuỗi sb2: ");
        String sb2 = input.readLine();
        System.out.println("Nhập chuỗi sb3: ");
        String sb3 = input.readLine();
        System.out.println("Nhập chuỗi sb4: ");
        String sb4 = input.readLine();
        System.out.println("Nhập vào vị trí cần chèn: ");
        int x = Integer.parseInt(input.readLine());
        System.out.println("Nhập vào vị trí đầu để xóa: ");
        int vtd = Integer.parseInt(input.readLine());
        System.out.println("Nhập vào vị trí cuối để xóa: ");
        int vtc = Integer.parseInt(input.readLine());
        
        chieuDai(sb1);
        chieuDai(sb2);
        chieuDai(sb3);
        chieuDai(sb4);
        xuLyChuoi(sb1, sb2, sb3, sb4, x, vtd, vtc);
        
        
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
