/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_part1_truongngoctinhanh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai11_1_XuLyChuoi {

    /**
     * @param args the command line arguments
     */
    public static void chieuDai(String s){
        int le = s.length();
        System.out.println("Chiều dài của chuỗi " + s + " là: " + le);
    }
    
    public static void soSanhChuoi(String s1, String s2){
        int tam = s1.compareTo(s2);
        if (tam == 0) System.out.println("Chuỗi s1 bằng chuỗi s2");
        else if (tam > 0) System.out.println("Chuỗi s1 lớn hơn chuỗi s2");
        else System.out.println("Chuỗi s1 nhỏ hơn chuỗi s2");
        
    }
    
    public static void noiChuoi(String s1, String s2){
        String s = s1.concat(s2);
        System.out.println("Chuổi tạo thành khi nối chuổi s2 vào sau chuỗi s1 là: " + s);
    }
    
    public static void timVTDauTien(String s1, String s2){
        int tam = s1.indexOf(s2);
        System.out.println("Vị trí xuất hiện đầu tiên của chuỗi " + s2 + " trong chuỗi " + s1 + " là: " + tam);
    }
    
    public static void taoChuoi(String s1, int v){
        String s4 = s1.substring(v);
        System.out.println("Chuỗi s4: " + s4);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập chuỗi s1: ");
        try{
        String s1 = input.readLine();
        System.out.println("Nhập chuỗi s2: ");
        String s2 = input.readLine();
        System.out.println("Nhập chuỗi s3: ");
        String s3 = input.readLine();
        System.out.println("Nhập vào vị trí cần tìm: ");
        int v = Integer.parseInt(input.readLine());
        chieuDai(s1);
        chieuDai(s2);
        chieuDai(s3);
        soSanhChuoi(s1, s2);
        noiChuoi(s1, s2);
        timVTDauTien(s1, s3);
        taoChuoi(s1, v);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
