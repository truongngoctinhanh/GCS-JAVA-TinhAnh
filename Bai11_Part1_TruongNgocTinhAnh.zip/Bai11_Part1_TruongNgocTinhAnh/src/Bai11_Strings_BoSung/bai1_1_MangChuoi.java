/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11_Strings_BoSung;

import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.chieuDai;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.noiChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.soSanhChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.taoChuoi;
import static bai11_part1_truongngoctinhanh.bai11_1_XuLyChuoi.timVTDauTien;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class bai1_1_MangChuoi {

    /**
     * @param args the command line arguments
     */
    
    public static void nhapMang(String[] mang, int n) throws IOException{
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for(int i = 0; i < mang.length; i++){
            System.out.print("Nhập phần tử thứ " + i + " = ");
            mang[i] = input.readLine();
        }
    }
    
    public static void xuatMang(String[]mang){
        for (int i = 0; i < mang.length; i++){
            System.out.print("\t" + mang[i]);
        }
        System.out.print("\n");
    } 
    
    public static void kiemTraTen(String[] mang, String ten){
        for (int i = 0; i < mang.length; i++){
            if(mang[i].equalsIgnoreCase(ten)){
                System.out.println("Tên của bạn có xuất hiện trong mảng tại vi trí " + i);
                break;
            }
        }
    }
    
    public static void timN(String[] mang){
        for (int i = 0; i < mang.length; i++){
            if(mang[i].contains("n")){
                System.out.println("Những phần tử có ký tự n là " + mang[i]);
            }
        }
    }
    
    
    public static void sapXepMang(String[] mang){
        Arrays.sort(mang);
        System.out.println("Mảng sau khi đã sắp xếp là: ");
        for (int i = 0; i < mang.length; i++){
            System.out.println(mang[i]);
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập n : ");
        try{
        int n = Integer.parseInt(input.readLine());
        String[] a = new String[n];
        nhapMang(a, n);
        xuatMang(a);
        
        System.out.println("Nhập vào tên một người : ");
        String ten = input.readLine();
        
        kiemTraTen(a, ten);
        timN(a);
        sapXepMang(a);
        
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
