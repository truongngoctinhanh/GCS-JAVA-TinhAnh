/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11_Strings_BoSung;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai1_5_HienThiMaTranKieuChuoi {

    /**
     * @param args the command line arguments
     */
    
    public static void maTranA(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i >= j) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "";
                }

            }
        }
    }

    public static void maTranB(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i <= j) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "";
                }

            }
        }
    }

    public static void maTranC(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i <= j) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }

            }
        }
    }

    public static void maTranD(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i + j < a.length - 1) {
                    a[i][j] = "  ";
                } else {
                    a[i][j] = "# ";
                }

            }
        }
    }

    public static void maTranE(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || j == 0 || j == a.length - 1) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }
            }
        }
    }

    public static void maTranF(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }
            }
        }
    }

    public static void maTranG(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i + j == a.length - 1) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }

            }
        }
    }

    public static void maTranH(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j || i + j == a.length - 1) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }

            }
        }
    }

    public static void maTranI(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i == 0 || i == a.length - 1 || i == j || i + j == a.length - 1 || j == 0 || j == a.length - 1) {
                    a[i][j] = "# ";
                } else {
                    a[i][j] = "  ";
                }

            }
        }
    }
    
    public static void inMaTran(String[][] a) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                System.out.print(a[i][j]);
            }
            System.out.println("\n");
        }
    }
    
    public static void main(String[] args) throws IOException{
        // TODO code application logic here
        BufferedReader nhap = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Nhập kích thước ma trận: ");
            int n = Integer.parseInt(nhap.readLine());
            String[][] a = new String[n][n];
            System.out.println("Hình A");
            maTranA(a);
            inMaTran(a);
            System.out.println("Hình B");
            maTranB(a);
            inMaTran(a);
            System.out.println("Hình C");
            maTranC(a);
            inMaTran(a);
            System.out.println("Hình D");
            maTranD(a);
            inMaTran(a);
            System.out.println("Hình E");
            maTranE(a);
            inMaTran(a);
            System.out.println("Hình F");
            maTranF(a);
            inMaTran(a);
            System.out.println("Hình G");
            maTranG(a);
            inMaTran(a);
            System.out.println("Hình H");
            maTranH(a);
            inMaTran(a);
            System.out.println("Hình I");
            maTranI(a);
            inMaTran(a);
        } catch (NumberFormatException ex) {
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
