/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11_Strings_BoSung;

import static Bai11_Strings_BoSung.bai1_3_SoSanh_String_StringBuilder.chuoi;
import static Bai11_Strings_BoSung.bai1_3_SoSanh_String_StringBuilder.chuoiStringBuilder;

/**
 *
 * @author hocvien
 */
public class bai1_4_SoSanh_Char_String_StringBuilder {

    /**
     * @param args the command line arguments
     */
    
    public static void chuoiStringBuilder1(){
         StringBuilder sb1 = new StringBuilder();
        for(int i = 0; i < 10000; i++){
            sb1 = sb1.append('A');
        }
        System.out.println(sb1);
        System.out.println("Chiều dài của chuỗi sb1: " + sb1.length());
    }
    
    public static void chuoiStringBuilder2(){
        StringBuilder sb2 = new StringBuilder(); 
        for(int i = 0; i < 10000; i++){
            sb2 = sb2.append("A");
        }
        System.out.println(sb2);        
        System.out.println("Chiều dài của chuỗi sb2: " + sb2.length());
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        long t1 = System.currentTimeMillis();
        chuoiStringBuilder1();
        long t2 = System.currentTimeMillis();
        chuoiStringBuilder2();
        long t3 = System.currentTimeMillis();
        long tg1 = t2 - t1;
        long tg2 = t3 - t2;
        System.out.println("Thời gian thực hiện sb1: " + tg1 + " milisecond");
        System.out.println("Thời gian thực hiện sb2: " + tg2 + " milisecond");
        if(tg1 > tg2){
            System.out.println("Thời gian thêm char dài hơn String");
        }else
            System.out.println("Thời gian thêm String dài hơn char");
    
    }
    
}
