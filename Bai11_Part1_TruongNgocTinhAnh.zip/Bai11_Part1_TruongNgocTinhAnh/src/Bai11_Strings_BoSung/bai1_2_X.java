/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11_Strings_BoSung;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai1_2_X {

    /**
     * @param args the command line arguments
     */
    
    public static void xuLyChuoi (StringBuilder sb){
        for(int i = 0; i < sb.length(); i++){
            System.out.println(sb.charAt(i));
        }
    }
    
    public static void timChuoiKT(StringBuilder sb, String kt){
        if(sb.indexOf(kt) >= 0){
            System.out.println("Chuỗi " + kt + " xuất hiện trong chuỗi " + sb + " tại vị trí: " + sb.indexOf(kt));
        }else
            System.out.println("Chuỗi " + kt + " không xuất hiện trong chuỗi " + sb);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader (System.in));
        System.out.println("Nhập chuỗi sb: ");
        try{
        StringBuilder sb = new StringBuilder(input.readLine());
        xuLyChuoi(sb);
        
        System.out.println("Nhập chuỗi kt: ");
        String kt = input.readLine();
        
        timChuoiKT(sb, kt);
        
        }catch(IOException | NumberFormatException | ArithmeticException ex){
            System.out.println("Lỗi: " + ex.getMessage());
        }
    }
    
}
