/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai11_Strings_BoSung;

import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai1_3_SoSanh_String_StringBuilder {

    /**
     * @param args the command line arguments
     */
    
    public static void chuoi(){
        String s = "";
        for(int i = 0; i < 10000; i++){
            s += i + " ";
        }
        System.out.println(s);
        System.out.println("Chiều dài của chuỗi String s: " + s.length());
    }
    
    public static void chuoiStringBuilder(){
        StringBuilder sb = new StringBuilder(); 
        for(int i = 0; i < 10000; i++){
            
            sb = sb.append(i + " ");
        }
        System.out.println(sb);        
        System.out.println("Chiều dài của chuỗi String sb: " + sb.length());
    }
    
    public static void main(String[] args) {
        // TODO code application logic here        
        long t1 = System.currentTimeMillis();
        chuoi();
        long t2 = System.currentTimeMillis();
        chuoiStringBuilder();
        long t3 = System.currentTimeMillis();
        long tg1 = t2 - t1;
        long tg2 = t3 - t2;
        System.out.println("Thời gian thực hiện s: " + tg1 + " milisecond");
        System.out.println("Thời gian thực hiện sb: " + tg2 + " milisecond");
        if(tg1 > tg2){
            System.out.println("Thời gian s dài hơn thời gian sb");
        }else
            System.out.println("Thời gian sb dài hơn thời gian s");
    }
}
